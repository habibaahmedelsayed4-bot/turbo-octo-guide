import { useEffect, useState } from 'react';
import { Activity, BriefcaseBusiness, CheckSquare, ChevronDown, CircleHelp, Files, FolderKanban, LayoutDashboard, Menu, Settings, UserRound } from 'lucide-react';
import { Link, NavLink, Navigate, Outlet, Route, Routes, useLocation } from 'react-router-dom';
import { useWorkspace } from './WorkspaceContext';
import { OwnerSignature } from './Branding';
import { LandingPage, NameSetupPage } from '../pages/PublicPages';
import { DashboardPage } from '../pages/DashboardPage';
import { ProjectsPage, ProjectDetailPage, WorkspacePage } from '../pages/ProjectsPage';
import { TasksPage } from '../pages/TasksPage';
import { FilesPage } from '../pages/FilesPage';
import { ActivityPage } from '../pages/ActivityPage';
import { HelpPage, ProfilePage, SettingsPage } from '../pages/SettingsPage';

const navigation = [
  { to: '/app', label: 'لوحة التحكم', icon: LayoutDashboard, end: true },
  { to: '/app/workspace', label: 'مساحة العمل', icon: BriefcaseBusiness },
  { to: '/app/projects', label: 'المشاريع', icon: FolderKanban },
  { to: '/app/tasks', label: 'المهام', icon: CheckSquare },
  { to: '/app/files', label: 'الملفات', icon: Files },
  { to: '/app/activity', label: 'النشاط', icon: Activity },
  { to: '/app/settings', label: 'الإعدادات', icon: Settings },
];

function Brand({ compact = false }: { compact?: boolean }) {
  return <span className={`brand-lockup${compact ? ' compact' : ''}`}><span className="brand-mark" aria-hidden="true"><i /><i /></span><span className="brand-word">NEXO</span></span>;
}

function ProtectedApp() {
  const { state } = useWorkspace();
  return state.name ? <Outlet /> : <Navigate to="/welcome" replace />;
}

function Sidebar({ onNavigate }: { onNavigate?: () => void }) {
  const { state } = useWorkspace();
  const [accountOpen, setAccountOpen] = useState(false);
  const initials = state.name.trim().slice(0, 1) || 'ن';
  return <aside className="sidebar" dir="rtl">
    <div className="sidebar-top">
      <div className="sidebar-brand-row"><Link className="brand-link" to="/app" onClick={onNavigate}><Brand /></Link><OwnerSignature /></div>
      <Link className="workspace-switcher" to="/app/workspace" onClick={onNavigate}>
        <span className="workspace-icon">{state.workspaceName.trim().slice(0, 1) || 'ن'}</span>
        <span className="workspace-switcher-copy"><strong>{state.workspaceName}</strong><small>مساحة شخصية</small></span>
        <ChevronDown size={15} className="workspace-chevron" />
      </Link>
    </div>
    <div className="nav-caption">مساحة العمل</div>
    <nav className="primary-nav" aria-label="التنقل الرئيسي">
      {navigation.map(({ to, label, icon: Icon, end }) => <NavLink key={to} to={to} end={end} onClick={onNavigate} className={({ isActive }) => `nav-link${isActive ? ' active' : ''}`}>
        <Icon size={18} strokeWidth={1.8} /><span>{label}</span>
        {label === 'المهام' && <span className="nav-count">{state.tasks.filter((task) => task.status !== 'مكتملة').length}</span>}
      </NavLink>)}
    </nav>
    <div className="sidebar-spacer" />
    <Link className="help-link" to="/app/help" onClick={onNavigate}><CircleHelp size={17} /><span>المساعدة والدعم</span><span className="help-shortcut">؟</span></Link>
    <div className="sidebar-account-wrap">
      {accountOpen && <div className="account-menu">
        <Link to="/app/profile" onClick={() => { setAccountOpen(false); onNavigate?.(); }}><UserRound size={16} /> الملف الشخصي</Link>
        <Link to="/app/settings" onClick={() => { setAccountOpen(false); onNavigate?.(); }}><Settings size={16} /> الإعدادات</Link>
        <Link to="/app/help" onClick={() => { setAccountOpen(false); onNavigate?.(); }}><CircleHelp size={16} /> المساعدة</Link>
        <div className="account-menu-note">بياناتك محفوظة على هذا الجهاز</div>
      </div>}
      <button className={`account-button${accountOpen ? ' open' : ''}`} onClick={() => setAccountOpen((open) => !open)} aria-expanded={accountOpen}>
        <span className="avatar">{initials}</span><span className="account-copy"><strong>{state.name}</strong><small>مساحة شخصية</small></span><ChevronDown size={15} className="account-chevron" />
      </button>
    </div>
  </aside>;
}

function AppLayout() {
  const [mobileOpen, setMobileOpen] = useState(false);
  const location = useLocation();
  const { state } = useWorkspace();
  useEffect(() => setMobileOpen(false), [location.pathname]);
  return <div className="app-frame" dir="ltr">
    {mobileOpen && <button className="mobile-backdrop" aria-label="إغلاق القائمة" onClick={() => setMobileOpen(false)} />}
    <div className={`sidebar-frame${mobileOpen ? ' mobile-open' : ''}`}><Sidebar onNavigate={() => setMobileOpen(false)} /></div>
    <div className="app-main" dir="rtl">
      <header className="mobile-header"><button className="icon-button mobile-menu-button" onClick={() => setMobileOpen(true)} aria-label="فتح القائمة"><Menu size={21} /></button><Link to="/app" className="mobile-brand"><Brand compact /></Link><OwnerSignature /><span className="mobile-avatar">{state.name.slice(0, 1)}</span></header>
      <Outlet />
    </div>
  </div>;
}

function NotFound() {
  return <main className="not-found"><Brand /><h1>هذه الصفحة غير موجودة</h1><p>قد يكون الرابط قد تغيّر. يمكنك العودة إلى مساحة العمل.</p><Link className="button button-primary" to="/app">العودة إلى لوحة التحكم</Link></main>;
}

function StorageNotice() {
  const [visible, setVisible] = useState(false);
  useEffect(() => {
    const showNotice = () => {
      setVisible(true);
      window.setTimeout(() => setVisible(false), 5000);
    };
    window.addEventListener('nexo:storage-error', showNotice);
    return () => window.removeEventListener('nexo:storage-error', showNotice);
  }, []);
  return visible ? <div className="storage-error-toast" role="alert">تعذر حفظ التغييرات. قد يكون تخزين هذا المتصفح ممتلئًا.</div> : null;
}

export function App() {
  return <><StorageNotice /><Routes>
    <Route path="/" element={<LandingPage />} />
    <Route path="/welcome" element={<NameSetupPage />} />
    <Route element={<ProtectedApp />}>
      <Route path="/app" element={<AppLayout />}>
        <Route index element={<DashboardPage />} />
        <Route path="workspace" element={<WorkspacePage />} />
        <Route path="projects" element={<ProjectsPage />} />
        <Route path="projects/:projectId" element={<ProjectDetailPage />} />
        <Route path="tasks" element={<TasksPage />} />
        <Route path="files" element={<FilesPage />} />
        <Route path="activity" element={<ActivityPage />} />
        <Route path="settings" element={<SettingsPage />} />
        <Route path="profile" element={<ProfilePage />} />
        <Route path="help" element={<HelpPage />} />
      </Route>
    </Route>
    <Route path="*" element={<NotFound />} />
  </Routes></>;
}
