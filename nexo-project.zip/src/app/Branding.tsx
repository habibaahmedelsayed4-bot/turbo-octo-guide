export function OwnerSignature() {
  return <span className="owner-signature" dir="ltr" aria-label="NEXO owner: Bebo" title="NEXO owner: Bebo">
    <span className="owner-signature-label">Owner</span>
    <span className="owner-signature-dot" aria-hidden="true" />
    <span className="owner-signature-name" dir="ltr">Bebo</span>
  </span>;
}
