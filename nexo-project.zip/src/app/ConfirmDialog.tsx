import { AlertTriangle } from 'lucide-react';
import { Modal } from './Modal';

interface ConfirmDialogProps {
  title: string;
  description: string;
  confirmLabel: string;
  onConfirm: () => void | Promise<void>;
  onClose: () => void;
  busy?: boolean;
}

export function ConfirmDialog({ title, description, confirmLabel, onConfirm, onClose, busy = false }: ConfirmDialogProps) {
  const titleId = 'confirm-dialog-title';
  return <Modal labelledBy={titleId} onClose={busy ? () => undefined : onClose} className="confirm-dialog">
    <button className="modal-close" type="button" onClick={onClose} disabled={busy} aria-label="إغلاق نافذة التأكيد"><span>×</span></button>
    <span className="modal-icon modal-icon-danger"><AlertTriangle size={19} /></span>
    <span className="page-eyebrow">تأكيد الإجراء</span>
    <h2 id={titleId}>{title}</h2>
    <p>{description}</p>
    <div className="modal-actions"><button className="button button-danger" type="button" disabled={busy} onClick={() => { void onConfirm(); }}>{busy ? 'جارٍ التنفيذ…' : confirmLabel}</button><button className="button button-outline" type="button" disabled={busy} onClick={onClose}>إلغاء</button></div>
  </Modal>;
}
