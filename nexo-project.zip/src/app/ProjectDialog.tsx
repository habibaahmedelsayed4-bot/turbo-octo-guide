import { useState, type FormEvent } from 'react';
import { ArrowLeft, FolderKanban } from 'lucide-react';
import { Modal } from './Modal';
import { useWorkspace } from './WorkspaceContext';
import type { Project } from '../data/model';

interface ProjectDialogProps {
  project?: Project;
  onClose: () => void;
}

export function ProjectDialog({ project, onClose }: ProjectDialogProps) {
  const { addProject, updateProject } = useWorkspace();
  const [name, setName] = useState(project?.name ?? '');
  const [description, setDescription] = useState(project?.description ?? '');
  const [error, setError] = useState('');
  const titleId = 'project-dialog-title';

  const submit = (event: FormEvent) => {
    event.preventDefault();
    const trimmedName = name.trim();
    if (!trimmedName) { setError('أضف اسمًا للمشروع للمتابعة.'); return; }
    if (Array.from(trimmedName).length > 80) { setError('اجعل اسم المشروع 80 حرفًا أو أقل.'); return; }
    if (/[\u0000-\u001F\u007F]/.test(trimmedName)) { setError('احذف محارف التحكم من اسم المشروع.'); return; }
    const trimmedDescription = description.trim();
    if (project) updateProject(project.id, { name: trimmedName, description: trimmedDescription });
    else addProject({ name: trimmedName, description: trimmedDescription, progress: 0, status: 'قيد التنفيذ' });
    onClose();
  };

  return <Modal labelledBy={titleId} onClose={onClose}>
    <button className="modal-close" type="button" onClick={onClose} aria-label="إغلاق النافذة"><span>×</span></button>
    <span className="modal-icon"><FolderKanban size={19} /></span>
    <span className="page-eyebrow">مساحة عملك</span>
    <h2 id={titleId}>{project ? 'تعديل المشروع' : 'مشروع جديد'}</h2>
    <p>{project ? 'حدّث الاسم أو الوصف. ستبقى المهام والملفات المرتبطة كما هي.' : 'ابدأ بإضافة تفاصيل بسيطة، ويمكنك تعديلها لاحقًا.'}</p>
    <form onSubmit={submit} className="form-stack" noValidate>
      <label htmlFor="project-name">اسم المشروع<input id="project-name" data-autofocus maxLength={100} value={name} onChange={(event) => { setName(event.target.value); setError(''); }} placeholder="مثال: إطلاق المنتج" aria-invalid={Boolean(error)} aria-describedby={error ? 'project-form-error' : undefined} /></label>
      <label htmlFor="project-description">وصف مختصر<textarea id="project-description" rows={3} maxLength={300} value={description} onChange={(event) => setDescription(event.target.value)} placeholder="ما الذي تعمل عليه؟" /></label>
      {error && <span className="field-error" id="project-form-error" role="alert">{error}</span>}
      <div className="modal-actions"><button className="button button-primary" type="submit">{project ? 'حفظ التغييرات' : 'إنشاء المشروع'} <ArrowLeft size={15} /></button><button className="button button-outline" type="button" onClick={onClose}>إلغاء</button></div>
    </form>
  </Modal>;
}
