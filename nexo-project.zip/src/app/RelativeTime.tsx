import { useEffect, useState } from 'react';
import { formatDateTime, formatRelativeTime } from '../data/format';

export function RelativeTime({ value, className }: { value: string | null | undefined; className?: string }) {
  const [now, setNow] = useState(() => Date.now());
  useEffect(() => {
    if (!value) return;
    const timer = window.setInterval(() => setNow(Date.now()), 60_000);
    return () => window.clearInterval(timer);
  }, [value]);
  const timestamp = value && !Number.isNaN(new Date(value).getTime()) ? value : undefined;
  return <time className={className} dateTime={timestamp} title={timestamp ? formatDateTime(timestamp) : 'لا يتوفر وقت محفوظ لهذا الحدث'}>{formatRelativeTime(value, now)}</time>;
}
