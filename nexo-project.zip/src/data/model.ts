export type ProjectStatus = 'قيد التنفيذ' | 'قيد المراجعة' | 'مكتمل';
export type TaskStatus = 'لم تبدأ' | 'قيد التنفيذ' | 'مكتملة';
export type Priority = 'منخفضة' | 'متوسطة' | 'عالية';
export type ActivityKind = 'project' | 'task' | 'file' | 'settings';

export interface Project {
  id: string;
  name: string;
  description: string;
  progress: number;
  status: ProjectStatus;
  updatedAt: string | null;
  tasksCount: number;
  color: string;
  archived: boolean;
}

export interface Task {
  id: string;
  name: string;
  projectId: string;
  priority: Priority;
  /** Empty string means the user chose no due date. */
  dueDate: string;
  status: TaskStatus;
}

export interface WorkspaceFile {
  id: string;
  name: string;
  type: string;
  size: number;
  date: string;
  owner: string;
  localBlob?: boolean;
  projectId?: string;
}

export interface ActivityItem {
  id: string;
  title: string;
  description: string;
  createdAt: string | null;
  kind: ActivityKind;
  projectId?: string;
}

export interface Preferences {
  theme: 'dark' | 'light';
  localAlerts: boolean;
  projectNotifications: boolean;
  taskNotifications: boolean;
}

export interface WorkspaceState {
  name: string;
  workspaceName: string;
  preferences: Preferences;
  projects: Project[];
  tasks: Task[];
  files: WorkspaceFile[];
  activities: ActivityItem[];
  metrics: { completedTasks: number; fileCount: number; recentActivity: number };
}

export function getProjectTaskCount(projectId: string, tasks: Task[]): number {
  return tasks.filter((task) => task.projectId === projectId).length;
}

export function getProjectProgress(projectId: string, tasks: Task[]): number {
  const projectTasks = tasks.filter((task) => task.projectId === projectId);
  if (projectTasks.length === 0) return 0;
  const completed = projectTasks.filter((task) => task.status === 'مكتملة').length;
  return Math.round((completed / projectTasks.length) * 100);
}

export function createInitialState(): WorkspaceState {
  return {
    name: '',
    workspaceName: 'مساحة NEXO',
    preferences: { theme: 'dark', localAlerts: false, projectNotifications: true, taskNotifications: true },
    projects: [],
    tasks: [],
    files: [],
    activities: [],
    metrics: { completedTasks: 0, fileCount: 0, recentActivity: 0 },
  };
}

export const STATE_KEY = 'nexo.workspace.v1';
export const MAX_LOCAL_FILE_BYTES = 20 * 1024 * 1024;
