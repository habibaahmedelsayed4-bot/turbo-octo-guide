import { Activity, CheckCheck, FileUp, FolderPlus, Settings, SlidersHorizontal } from 'lucide-react';
import { useMemo, useState } from 'react';
import { RelativeTime } from '../app/RelativeTime';
import { groupActivityDate } from '../data/format';
import { useWorkspace } from '../app/WorkspaceContext';
import type { ActivityItem } from '../data/model';
import { EmptyState, PageHeader, SectionCard } from './Shared';

const iconByKind = {
  project: FolderPlus,
  task: CheckCheck,
  file: FileUp,
  settings: Settings,
};

export function ActivityPage() {
  const { state } = useWorkspace();
  const [filter, setFilter] = useState('الكل');
  const visible = useMemo(() => state.activities.filter((item) => filter === 'الكل'
    || (filter === 'المشاريع' && item.kind === 'project')
    || (filter === 'المهام' && item.kind === 'task')
    || (filter === 'الملفات' && item.kind === 'file')
    || (filter === 'الإعدادات' && item.kind === 'settings')),
  [filter, state.activities]);
  const byDate = visible.reduce<Record<string, ActivityItem[]>>((groups, item) => {
    const key = groupActivityDate(item.createdAt);
    groups[key] = [...(groups[key] ?? []), item];
    return groups;
  }, {});

  return <main className="page-content">
    <PageHeader eyebrow="سجل مساحة العمل" title="النشاط" description="تتبّع ما تغيّر، ومتى حدث فعلًا." action={<label className="select-control"><span className="sr-only">تصفية النشاط</span><SlidersHorizontal size={15} /><select value={filter} onChange={(event) => setFilter(event.target.value)} aria-label="تصفية النشاط"><option>الكل</option><option>المشاريع</option><option>المهام</option><option>الملفات</option><option>الإعدادات</option></select></label>} />
    <SectionCard className="activity-page-card">
      <div className="activity-timeline">
        {Object.entries(byDate).length ? Object.entries(byDate).map(([group, items]) => <section className="timeline-group" key={group} aria-label={`النشاط: ${group}`}>
          <h2>{group}</h2>
          {items.map((item) => {
            const Icon = iconByKind[item.kind];
            return <article className="timeline-event" key={item.id}>
              <span className={`timeline-icon kind-${item.kind}`} aria-hidden="true"><Icon size={16} /></span>
              <span className="timeline-stem" aria-hidden="true" />
              <div className="timeline-event-copy"><div><strong>{item.title}</strong><RelativeTime value={item.createdAt} /></div><p>{item.description}</p></div>
            </article>;
          })}
        </section>) : <EmptyState title="لا توجد أحداث هنا" description={state.activities.length ? 'لا توجد أحداث من هذا النوع بعد.' : 'سيظهر هنا ما تنجزه فعلًا في مساحة العمل.'} />}
      </div>
    </SectionCard>
    <div className="local-data-footnote"><Activity size={14} /> سجل النشاط جزء من مساحة العمل المحلية على هذا الجهاز.</div>
  </main>;
}
