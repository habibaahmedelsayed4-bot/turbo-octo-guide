import { ArrowLeft, ArrowUpLeft, Check, FileText, FolderKanban, LayoutDashboard, LockKeyhole, Sparkles, Zap } from 'lucide-react';
import { Link, useNavigate } from 'react-router-dom';
import { useState, type FormEvent } from 'react';
import { useWorkspace } from '../app/WorkspaceContext';
import { OwnerSignature } from '../app/Branding';

function Logo() {
  return <span className="brand-lockup"><span className="brand-mark" aria-hidden="true"><i /><i /></span><span className="brand-word">NEXO</span></span>;
}

function DashboardPreview() {
  return <div className="preview-shell" aria-label="معاينة لوحة التحكم">
    <div className="preview-topbar"><span className="preview-dot" /><span className="preview-dot" /><span className="preview-dot" /><span className="preview-top-title">مساحة NEXO</span><span className="preview-avatar">N</span></div>
    <div className="preview-body">
      <div className="preview-sidebar"><div className="preview-logo-mark">N</div>{[LayoutDashboard, FolderKanban, Check, FileText].map((Icon, index) => <span className={`preview-nav-icon${index === 0 ? ' selected' : ''}`} key={index}><Icon size={13} /></span>)}</div>
      <div className="preview-content">
        <div className="preview-eyebrow">مساحة شخصية</div>
        <div className="preview-heading">ابدأ من هنا <span>✦</span></div>
        <div className="preview-subheading">التقدم يُحسب من مهامك المنجزة فعلًا.</div>
        <div className="preview-stat-row"><div><span>المشاريع النشطة</span><strong>0</strong></div><div><span>المهام المكتملة</span><strong>0</strong></div><div><span>الملفات</span><strong>0</strong></div></div>
        <div className="preview-lower"><div className="preview-projects"><span className="preview-section-title">المشاريع الأخيرة</span><div className="preview-empty"><span className="project-mini-dot" /> لا توجد مشاريع بعد</div><small className="preview-empty-hint">أضف مشروعك الأول لتبدأ احتساب التقدم.</small></div><div className="preview-activity"><span className="preview-section-title">آخر النشاط</span><div className="preview-activity-empty">سيظهر نشاطك هنا عند بدء العمل.</div></div></div>
      </div>
    </div>
    <div className="preview-float"><span className="preview-float-icon"><FolderKanban size={16} /></span><span><small>مساحة جديدة</small><strong>ابدأ أول مشروع</strong></span></div>
  </div>;
}

export function LandingPage() {
  const { state } = useWorkspace();
  const navigate = useNavigate();
  const start = () => navigate(state.name ? '/app' : '/welcome');
  return <div className="landing-page" dir="rtl">
    <nav className="landing-nav"><Link className="brand-link" to="/"><Logo /></Link><div className="landing-nav-links"><OwnerSignature /><a href="#features">المميزات</a><button className="button button-quiet" onClick={start}>{state.name ? 'متابعة إلى مساحة العمل' : 'مساحة العمل'}</button></div></nav>
    <main>
      <section className="hero-section">
        <div className="hero-copy">
          <span className="eyebrow"><span className="eyebrow-mark"><Sparkles size={13} /></span> مساحة عمل مصممة للتركيز</span>
          <h1>كل عملك في مكان واحد.<br /><span>بوضوح أكبر.</span></h1>
          <p className="hero-description">اجمع مشاريعك ومهامك وملفاتك في مساحة هادئة تساعدك على التقدم — خطوة واضحة تليها خطوة.</p>
          <div className="hero-actions"><button className="button button-primary button-lg" onClick={start}>{state.name ? 'افتح مساحة العمل' : 'ابدأ الآن'}<ArrowLeft size={17} /></button><a className="text-link" href="#features">اكتشف المميزات <ArrowUpLeft size={15} /></a></div>
          <div className="journey-flow" aria-label="رحلة الاستخدام"><div><span>01</span><strong>ابدأ باسمك</strong></div><i aria-hidden="true" /><div><span>02</span><strong>أنشئ مشروعك</strong></div><i aria-hidden="true" /><div><span>03</span><strong>أضف المهام</strong></div><i aria-hidden="true" /><div><span>04</span><strong>تابع تقدمك</strong></div></div>
          <div className="hero-proof"><span className="proof-mark"><Check size={14} /></span><p>ابدأ من الصفر، <strong>والنسب تعكس إنجازك.</strong></p></div>
        </div>
        <div className="hero-visual"><div className="visual-orbit orbit-one" /><div className="visual-orbit orbit-two" /><DashboardPreview /><div className="visual-caption"><span className="live-dot" /> معاينة مساحة العمل</div></div>
      </section>
      <section id="features" className="features-section">
        <div className="section-heading"><span className="eyebrow">مصممة لتبسيط يومك</span><h2>أقل تشتتًا. <span>تقدم أكثر.</span></h2><p>الأدوات التي تحتاجها للعمل معًا، دون ضجيج.</p></div>
        <div className="feature-grid">
          <article className="feature-card"><span className="feature-icon icon-blue"><FolderKanban size={19} /></span><h3>مشاريع واضحة</h3><p>تابع مراحل العمل والتقدم من نظرة واحدة.</p><span className="feature-micro">كل مشروع، بخطوته التالية</span></article>
          <article className="feature-card"><span className="feature-icon icon-mint"><Zap size={19} /></span><h3>مهام تتحرك</h3><p>رتّب الأولويات وحافظ على إيقاع عملك.</p><span className="feature-micro">من الفكرة إلى الإنجاز</span></article>
          <article className="feature-card"><span className="feature-icon icon-amber"><FileText size={19} /></span><h3>ملفات في سياقها</h3><p>احتفظ بملفاتك بالقرب من العمل الذي تنتمي إليه.</p><span className="feature-micro">تفاصيل أقل للبحث</span></article>
          <article className="feature-card"><span className="feature-icon icon-violet"><Check size={19} /></span><h3>مساحة هادئة</h3><p>واجهة بسيطة تمنح ما هو مهم مساحة للظهور.</p><span className="feature-micro">مصممة لليوم الحقيقي</span></article>
        </div>
      </section>
      <section className="closing-cta"><div><span className="eyebrow">مساحتك تبدأ هنا</span><h2>جاهز لترتيب أفكارك؟</h2><p>اكتب اسمك وابدأ مباشرة. لا حاجة لحساب.</p></div><button className="button button-primary" onClick={start}>{state.name ? 'تابع عملك' : 'ابدأ الآن'}<ArrowLeft size={16} /></button></section>
    </main>
    <footer className="landing-footer"><Logo /><OwnerSignature /><span>مساحة عملك، بوضوح.</span><small>© 2026 NEXO</small></footer>
  </div>;
}

export function NameSetupPage() {
  const { state, setName } = useWorkspace();
  const [name, setInputName] = useState(state.name);
  const [error, setError] = useState('');
  const navigate = useNavigate();
  const submit = (event: FormEvent) => {
    event.preventDefault();
    const value = name.trim();
    if (!value) { setError('اكتب اسمك للمتابعة.'); return; }
    if (Array.from(value).length > 32) { setError('اجعل الاسم 32 حرفًا أو أقل.'); return; }
    if (/[\u0000-\u001F\u007F]/.test(value)) { setError('احذف محارف التحكم من الاسم.'); return; }
    if (!setName(value)) { setError('تعذر حفظ الاسم في هذا المتصفح. تحقّق من مساحة التخزين وحاول مجددًا.'); return; }
    navigate('/app', { replace: true });
  };
  return <main className="welcome-screen" dir="rtl">
    <div className="welcome-side-note"><span className="welcome-line" />مساحتك، بطريقتك</div>
    <div className="welcome-card">
    <Link className="brand-link" to="/"><Logo /></Link>
    <div className="welcome-icon"><span className="brand-mark"><i /><i /></span></div>
    <span className="eyebrow">بداية بسيطة</span>
    <h1>{state.name ? 'كيف نُناديك؟' : 'أهلًا بك في NEXO'}</h1>
      <p>اكتب اسمك فقط، وسنجهّز لك مساحة عملك.</p>
      <form onSubmit={submit} className="welcome-form" noValidate>
        <label htmlFor="display-name">الاسم</label>
        <input id="display-name" autoComplete="given-name" maxLength={32} value={name} onChange={(event) => { setInputName(event.target.value); setError(''); }} placeholder="مثال: سام" aria-invalid={Boolean(error)} />
        {error && <span className="field-error">{error}</span>}
        <button className="button button-primary button-lg" type="submit">متابعة إلى مساحة العمل <ArrowLeft size={17} /></button>
      </form>
      <div className="local-note"><LockKeyhole size={14} /><span>اسمك وبيانات عملك محفوظة على هذا الجهاز فقط.</span></div>
      <Link className="welcome-back" to="/">العودة إلى الصفحة الرئيسية</Link>
    </div>
    <div className="welcome-bottom"><span>NEXO</span><span>مساحة عملك، بوضوح.</span></div>
  </main>;
}
