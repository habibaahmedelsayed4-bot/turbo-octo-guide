import { useMemo, useState } from 'react';
import { ArrowLeft, CalendarDays, Check, MoreHorizontal, Pencil, Plus, Search, SlidersHorizontal, Trash2 } from 'lucide-react';
import { Link } from 'react-router-dom';
import { ConfirmDialog } from '../app/ConfirmDialog';
import { TaskDialog } from '../app/TaskDialog';
import { useWorkspace } from '../app/WorkspaceContext';
import { formatDueDate, localDateKey } from '../data/format';
import type { Task, TaskStatus } from '../data/model';
import { EmptyState, PageHeader, StatusBadge } from './Shared';

const columns: TaskStatus[] = ['لم تبدأ', 'قيد التنفيذ', 'مكتملة'];

export function TasksPage() {
  const { state, updateTaskStatus, deleteTask } = useWorkspace();
  const [showDialog, setShowDialog] = useState(false);
  const [editingTask, setEditingTask] = useState<Task | null>(null);
  const [deletingTask, setDeletingTask] = useState<Task | null>(null);
  const [query, setQuery] = useState('');
  const [priorityFilter, setPriorityFilter] = useState('الكل');
  const today = localDateKey();
  const filtered = useMemo(() => state.tasks.filter((task) => `${task.name} ${state.projects.find((project) => project.id === task.projectId)?.name ?? ''}`.toLowerCase().includes(query.trim().toLowerCase()) && (priorityFilter === 'الكل' || task.priority === priorityFilter)), [state.tasks, state.projects, query, priorityFilter]);
  const openNewTask = () => { setEditingTask(null); setShowDialog(true); };
  const editTask = (task: Task, trigger: HTMLElement) => { trigger.closest('details')?.removeAttribute('open'); setEditingTask(task); setShowDialog(true); };
  const requestDelete = (task: Task, trigger: HTMLElement) => { trigger.closest('details')?.removeAttribute('open'); setDeletingTask(task); };
  const nextStatus = (status: TaskStatus): TaskStatus => status === 'لم تبدأ' ? 'قيد التنفيذ' : status === 'قيد التنفيذ' ? 'مكتملة' : 'قيد التنفيذ';

  return <main className="page-content">
    <PageHeader eyebrow="التنفيذ اليومي" title="المهام" description="حوّل الخطوات الصغيرة إلى تقدم ملموس." action={<button type="button" className="button button-primary" onClick={openNewTask}><Plus size={16} />إضافة مهمة</button>} />
    <div className="task-toolbar"><label className="search-control"><span className="sr-only">ابحث في المهام</span><Search size={16} /><input aria-label="ابحث في المهام" value={query} onChange={(event) => setQuery(event.target.value)} placeholder="ابحث في المهام" /></label><label className="select-control"><span className="sr-only">تصفية حسب الأولوية</span><SlidersHorizontal size={15} /><select aria-label="تصفية حسب الأولوية" value={priorityFilter} onChange={(event) => setPriorityFilter(event.target.value)}><option>الكل</option><option>عالية</option><option>متوسطة</option><option>منخفضة</option></select></label><span className="task-total">{filtered.length} مهمة</span></div>
    {filtered.length === 0 ? <EmptyState title={state.tasks.length ? 'لا توجد مهام مطابقة' : 'ابدأ بمهمة واضحة'} description={state.tasks.length ? 'غيّر عبارة البحث أو مرشح الأولوية.' : state.projects.length ? 'أضف مهمة إلى مشروع؛ التاريخ اختياري ويظل فارغًا حتى تختاره.' : 'أنشئ مشروعًا أولًا، ثم اربط به مهامك ليتغير التقدم عند إنجازها.'} action={<button type="button" className="button button-primary" onClick={openNewTask}><Plus size={15} />{state.projects.length ? 'إضافة مهمة' : 'إنشاء مشروع أو مهمة'}</button>} /> : <div className="task-board">{columns.map((status) => {
      const tasks = filtered.filter((task) => task.status === status);
      return <section className={`task-column column-${status === 'لم تبدأ' ? 'todo' : status === 'قيد التنفيذ' ? 'progress' : 'done'}`} key={status} aria-labelledby={`task-column-${status}`}>
        <div className="task-column-heading"><span className="column-status-dot" aria-hidden="true" /><h2 id={`task-column-${status}`}>{status}</h2><span className="column-count" aria-label={`${tasks.length} مهمة`}>{tasks.length}</span><button type="button" className="bare-icon" onClick={openNewTask} aria-label={`إضافة مهمة ${status}`}><Plus size={17} /></button></div>
        <div className="task-column-body">{tasks.map((task) => {
          const project = state.projects.find((item) => item.id === task.projectId);
          const overdue = task.status !== 'مكتملة' && Boolean(task.dueDate) && task.dueDate < today;
          return <article className={`task-card${status === 'مكتملة' ? ' task-card-done' : ''}`} key={task.id}>
            <div className="task-card-top"><StatusBadge tone={task.priority === 'عالية' ? 'danger' : task.priority === 'متوسطة' ? 'amber' : 'muted'}>{task.priority} الأولوية</StatusBadge><details className="entity-actions-menu"><summary className="entity-actions-trigger" aria-label={`إجراءات المهمة ${task.name}`}><MoreHorizontal size={16} /></summary><div className="entity-actions-panel" role="group"><button type="button" onClick={(event) => editTask(task, event.currentTarget)}><Pencil size={14} />تعديل المهمة</button><button type="button" className="danger-action" onClick={(event) => requestDelete(task, event.currentTarget)}><Trash2 size={14} />حذف المهمة</button></div></details></div>
            <h3 className={status === 'مكتملة' ? 'task-complete-text' : ''}>{task.name}</h3>
            <Link className="task-project-link" to={`/app/projects/${task.projectId}`}>{project?.name ?? 'مشروع غير متاح'} <ArrowLeft size={12} /></Link>
            <div className={`task-due-line${overdue ? ' overdue' : ''}`}><CalendarDays size={13} /><span>{formatDueDate(task.dueDate)}</span>{overdue && <StatusBadge tone="danger">متأخرة</StatusBadge>}</div>
            <div className="task-card-footer">{task.status !== 'مكتملة' ? <button type="button" className="task-advance" onClick={() => updateTaskStatus(task.id, nextStatus(task.status))}>{task.status === 'لم تبدأ' ? 'بدء المهمة' : 'إكمال المهمة'} <ArrowLeft size={13} /></button> : <button type="button" className="task-advance" onClick={() => updateTaskStatus(task.id, 'قيد التنفيذ')}>إعادة فتح <ArrowLeft size={13} /></button>}<button type="button" className={`task-complete-mini${status === 'مكتملة' ? ' checked' : ''}`} aria-label={status === 'مكتملة' ? 'إعادة فتح المهمة' : 'تحديد المهمة مكتملة'} onClick={() => updateTaskStatus(task.id, status === 'مكتملة' ? 'قيد التنفيذ' : 'مكتملة')}>{status === 'مكتملة' && <Check size={13} />}</button></div>
          </article>;
        })}{tasks.length === 0 && <div className="column-empty">لا توجد مهام في هذه الحالة</div>}</div>
      </section>;
    })}</div>}
    {showDialog && <TaskDialog task={editingTask ?? undefined} onClose={() => { setShowDialog(false); setEditingTask(null); }} />}
    {deletingTask && <ConfirmDialog title="حذف المهمة؟" description={`سيُحذف «${deletingTask.name}» من مساحة العمل، وستُعاد نسبة إنجاز المشروع المرتبط حسب المهام المتبقية.`} confirmLabel="حذف المهمة" onConfirm={() => { deleteTask(deletingTask.id); setDeletingTask(null); }} onClose={() => setDeletingTask(null)} />}
  </main>;
}
